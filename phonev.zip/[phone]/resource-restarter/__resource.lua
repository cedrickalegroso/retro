description "Resource Restarter"

server_script {
	'server.lua'
}